// miniprogram/pages/predict/predict.js
Page({
  record: function (e) {
    var num = 0;
    var which;
    const action = ["步行","深蹲起","原地跳绳","俄罗斯转体"];
    const w01 = [-68.16250869,165.38187454,-213.6678077,-1.46779523,-3.35987002,-15.66219783];
    const b01 = 40.66666638508548;
    const w02 = [-81.4939717,34.61763437,263.18878502,-27.20539051,61.15050547,16.38442745];
    const b02 = 190.80706834346483;
    const w03 = [62.97536227,40.78850165,-5.6585328,-4.64453211,7.78903076,-21.49121195];
    const b03 = -70.49755657118743;
    const w12 = [8.79557196,-131.12680295,334.8566841,66.25382158,53.21711293,113.47180726];
    const b12 = 132.03750651403817;
    const w13 = [8.6691331,-49.8765074,33.98731672,6.17660469,19.42491523,9.08726268];
    const b13 = -7.236751772629248;
    const w23 = [11.99353123,22.69249114,-50.7814112,-10.79888599,-26.81164328,-14.07464918];
    const b23 = -45.22007401575592;
    var acc_x = [];
    var acc_y = [];
    var acc_z = [];
    var gyr_x = [];
    var gyr_y = [];
    var gyr_z = [];

    wx.startAccelerometer({
      interval: 'game'
    })
    wx.startGyroscope({
      interval: 'game'
    })
    wx.showToast({
      title: '开始采集',
      icon: 'loading',
      mask: true,
      duration: 1000,
    })
    wx.onAccelerometerChange(function (res_a) {
      acc_x.push(res_a.x);
      acc_y.push(res_a.y);
      acc_z.push(res_a.z);
    })
    wx.onGyroscopeChange(function (res_g) {
      gyr_x.push(res_g.x);
      gyr_y.push(res_g.y);
      gyr_z.push(res_g.z);
    })
    wx.showToast({
      title: '正在识别',
      icon: 'loading',
      mask: true,
      duration: 1000,
    })
    setTimeout(function () {
      // feature generate
      var f = [];
      var i;
      var sum1 = 0;
      for (i = 100; i < 228; i++)
        sum1 += acc_x[i];
      f.push(sum1 / 128);

      var sum2 = 0;
      for (i = 100; i < 228; i++)
        sum2 += acc_y[i];
      f.push(sum2 / 128);

      var sum3 = 0;
      for (i = 100; i < 228; i++)
        sum3 += acc_z[i];
      f.push(sum3 / 128);

      var sum4 = 0;
      for (i = 100; i < 228; i++)
        sum4 += gyr_x[i];
      f.push(sum4 / 128);

      var sum5 = 0;
      for (i = 100; i < 228; i++)
        sum5 += gyr_y[i];
      f.push(sum5 / 128);

      var sum6 = 0;
      for (i = 100; i < 228; i++)
        sum6 += gyr_z[i];
      f.push(sum6 / 128);

      // conpute probability of each class
      var z01 = 0;
      var z02 = 0;
      var z03 = 0;
      var z12 = 0;
      var z13 = 0;
      var z23 = 0;
      for (i = 0; i < 6; i++) {
        z01 += f[i] * w01[i];
        z02 += f[i] * w02[i];
        z03 += f[i] * w03[i];
        z12 += f[i] * w12[i];
        z13 += f[i] * w13[i];
        z23 += f[i] * w23[i];
      }
      z01 += b01;
      z02 += b02;
      z03 += b03;
      z12 += b12;
      z13 += b13;
      z23 += b23;

      var p = [0, 0, 0, 0];
      p[0] = 1 / (1 + Math.exp(-z01) + Math.exp(-z02) + Math.exp(-z03));
      p[1] = 1 / (1 + Math.exp(z01) + Math.exp(-z12) + Math.exp(-z13));
      p[2] = 1 / (1 + Math.exp(z02) + Math.exp(z12) + Math.exp(-z23));
      p[3] = 1 / (1 + Math.exp(z03) + Math.exp(z13) + Math.exp(z23));

      if (p[0] > 0.6) {
        wx.showToast({
          title: action[0],
          icon: 'succes',
          mask: true,
          duration: 5000,
        })
        which = action[0]
      } else if (p[1] > 0.6) {
        wx.showToast({
          title: action[1],
          icon: 'succes',
          mask: true,
          duration: 5000,
        })
        which = action[1]
      } else if (p[2] > 0.6) {
        wx.showToast({
          title: action[2],
          icon: 'succes',
          mask: true,
          duration: 5000,
        })
        which = action[2]
      } else if (p[3] > 0.6) {
        wx.showToast({
          title: action[3],
          icon: 'succes',
          mask: true,
          duration: 5000,
        })
        which = action[3]
      } else {
        wx.showToast({
          title: '请重试',
          icon: 'succes',
          mask: true,
          duration: 3000,
        })
      }
    }, 4600)
    setTimeout(function () {
      wx.showToast({
        title: '请继续',
        icon: 'loading',
        mask: true,
        duration: 3000,
      })
    },10000)
    setTimeout(function () {
      wx.showToast({
        title: '还剩15秒',
        icon: 'loading',
        mask: true,
        duration: 1000,
      })
    },15000)
    setTimeout(function () {
      wx.showToast({
        title: '还剩10秒',
        icon: 'loading',
        mask: true,
        duration: 1000,
      })
    },20000)
    setTimeout(function () {
      wx.showToast({
        title: '还剩5秒',
        icon: 'loading',
        mask: true,
        duration: 1000,
      })
    },25000)
    var that = this;
    setTimeout(function () {
      wx.showToast({
        title: '计时结束',
        icon: 'succes',
        mask: true,
        duration: 1000,
      })
      var i;
      wx.stopAccelerometer({})
      wx.stopGyroscope({})
      for (i=2;i<1498;i++){
        acc_x[i] = acc_x.slice(i-2,i+3).sort()[2];
      }
      for (i=2;i<1498;i++){
        acc_x[i] = acc_x.slice(i-2,i+3).sort()[2];
      }
      for (i=2;i<1498;i++){
        acc_x[i] = acc_x.slice(i-2,i+3).sort()[2];
      }
      for (i=2;i<1498;i++){
        acc_x[i] = acc_x.slice(i-2,i+3).sort()[2];
      }
      for (i=6;i<1494;i++) {
        if(acc_x[i]-0.001>acc_x[i-6]&&acc_x[i]-0.001>acc_x[i-4]&&acc_x[i]-0.001>acc_x[i-2]&&acc_x[i]-0.001>acc_x[i+6]&&acc_x[i]-0.001>acc_x[i+4]&&acc_x[i]-0.001>acc_x[i+2]) {
          num = num + 1;
        }
      }
      that.setData({
        num: num,
        action:which
      })
      console.log(num);
    },30000)
  }
})