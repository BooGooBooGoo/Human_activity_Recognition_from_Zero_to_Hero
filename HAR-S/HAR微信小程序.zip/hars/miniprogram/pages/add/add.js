Page({
  record: function(e) {
    var which_action = e.currentTarget.dataset.id;
    var acc_x = [];
    var acc_y = [];
    var acc_z = [];
    var gyr_x = [];
    var gyr_y = [];
    var gyr_z = [];
    wx.showToast({
      title: '正在计时',
      icon: 'loading',
      mask: true,
      duration: 10000,
    })
    wx.startAccelerometer({
      interval: 'game'
    })
    wx.startGyroscope({
      interval: 'game'
    })
    const db = wx.cloud.database();
    wx.onAccelerometerChange(function (res_a) {
      acc_x.push(res_a.x);
      acc_y.push(res_a.y);
      acc_z.push(res_a.z);
    })
    wx.onGyroscopeChange(function (res_g) {
      gyr_x.push(res_g.x);
      gyr_y.push(res_g.y);
      gyr_z.push(res_g.z);
    })
    setTimeout(function () {
      wx.stopAccelerometer({
      })
      wx.stopGyroscope({
      })
      wx.showToast({
        title: '开始写入',
        icon: 'loading',
        mask: true,
        duration: 1000,
      })
      var i = 1;
      while(i<501) {
        db.collection("action"+which_action).add({
          data: {
            action: which_action,
            _id: i,
            ax: acc_x[i],
            ay: acc_y[i],
            az: acc_z[i],
            gx: gyr_x[i],
            gy: gyr_y[i],
            gz: gyr_z[i],
          },
          success: res => {
          },
          fail: err => {
            wx.showToast({
              title: '写入失败',
              icon: 'loading',
              mask: true,
              duration: 1000,
            })
          },
        })
        i = i + 1;
      }
      wx.showToast({
        title: '写入完成',
        icon: 'succes',
        mask: true,
        duration: 1000,
      })
    }, 10200)
  },
})