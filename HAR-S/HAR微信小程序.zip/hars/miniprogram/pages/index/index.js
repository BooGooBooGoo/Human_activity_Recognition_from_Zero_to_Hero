// pages/index/index.js
Page({
  navigateToAdd:function(event){
    wx.navigateTo({
      url:'../add/add',
    })
  },
  navigateToShow: function (event) {
    wx.navigateTo({
      url: '../predict/predict',
    })
  }
})